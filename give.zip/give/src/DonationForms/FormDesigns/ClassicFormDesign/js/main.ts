import Header from './layouts/Header';

window.givewp.form.templates.layouts.header = Header;
